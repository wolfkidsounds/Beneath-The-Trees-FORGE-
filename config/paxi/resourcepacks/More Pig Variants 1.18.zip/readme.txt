Hey! Thanks for downloading my resourcepack!

If you have any suggestions or just want to talk to me, you can do so through planetminecraft!
If I see a lot of support in the creations I make, maybe I'll put a donation system on my planetminecraft page.
I will be very grateful to anyone who is willing to support me!

- Don't steal my content or repost it under any circumstances!
- If you want to use my content for your own resourcepacks or port it to Bedrock you can DM me on 
  Discord (my Discord username is on my PlanetMinecraft page) and discuss it.
- In case you are recording a video or streaming with the resourcepack on, any credit will be appreciated!

Created by: ByBoxi

Planet Minecraft:
https://www.planetminecraft.com/member/byboxi/
Curseforge:
https://www.curseforge.com/members/byboxi_/projects