----------------[Terms of use]---------------------------

You may use everything we made in this pack when having asked for permission.
If given permission, you should credit us.

-------------------[Credit]------------------------------


--WeNAN Studios--

Linktr.ee: 			https://linktr.ee/wenan
Curse Forge:		https://www.curseforge.com/members/wenan_studios
Planet Minecraft:	https://www.planetminecraft.com/member/wenan_studios/
Twitter:			https://twitter.com/StudiosWenan


--Pack Creators--


mr_ch0c0late

Linktr.ee: 			https://linktr.ee/mr_ch0c0late
Curse Forge: 		https://www.curseforge.com/members/mr_ch0c0late1
Planet Minecraft: 	https://www.planetminecraft.com/member/mr_ch0c0late1/
Twitter: 			https://twitter.com/mr_ch0c0late1


Zartrix

Linktr.ee: 			https://linktr.ee/Zartrix
Curse Forge:		https://www.curseforge.com/members/zartrix
Planet Minecraft: 	https://www.planetminecraft.com/member/zartrix/
Twitter:			https://twitter.com/Zartrix_